-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2019 at 06:43 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eahthospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `addpatient`
--

CREATE TABLE `addpatient` (
  `p_id` int(8) NOT NULL,
  `p_firstName` varchar(30) NOT NULL,
  `p_lastName` varchar(30) NOT NULL,
  `p_age` int(3) NOT NULL,
  `p_dob` date NOT NULL,
  `p_contact` int(15) NOT NULL,
  `p_emergencyContact` int(15) NOT NULL,
  `p_gender` varchar(10) NOT NULL,
  `p_address` text DEFAULT NULL,
  `p_bedNum` int(15) NOT NULL,
  `p_floor` varchar(30) NOT NULL,
  `p_admission` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addpatient`
--

INSERT INTO `addpatient` (`p_id`, `p_firstName`, `p_lastName`, `p_age`, `p_dob`, `p_contact`, `p_emergencyContact`, `p_gender`, `p_address`, `p_bedNum`, `p_floor`, `p_admission`) VALUES
(1, 'Kay', 'Aum   ', 28, '1991-08-28', 165315884, 1073779041, 'Male   ', 'montkiara', 1, '1', '2019-08-15'),
(2, 'Jay', 'Jung   ', 24, '1995-06-14', 165555555, 184545556, 'Female   ', '', 2, '1', '2019-11-04'),
(3, 'John', 'Wick', 22, '1997-02-12', 140056344, 184845656, 'Male   ', 'Cheras', 3, '1', '2019-11-06'),
(4, 'Ashton', 'Aile  ', 22, '1997-03-10', 140055344, 184845656, 'Male   ', 'Cheras', 4, '1', '2019-11-02'),
(5, 'Mike', 'Dale', 22, '1997-11-10', 140063544, 184845656, 'Male   ', 'Cheras', 1, '2', '2019-11-18');

-- --------------------------------------------------------

--
-- Table structure for table `bed_active`
--

CREATE TABLE `bed_active` (
  `ba_id` int(15) NOT NULL,
  `ms_name` varchar(50) NOT NULL,
  `bed_number` int(3) NOT NULL,
  `emergency_datetime` datetime DEFAULT NULL,
  `staff_checkdatetime` datetime DEFAULT NULL,
  `systolic` int(3) DEFAULT NULL,
  `diastolic` int(3) DEFAULT NULL,
  `pulse` int(3) DEFAULT NULL,
  `breathing` int(3) DEFAULT NULL,
  `temperature` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bed_active`
--

INSERT INTO `bed_active` (`ba_id`, `ms_name`, `bed_number`, `emergency_datetime`, `staff_checkdatetime`, `systolic`, `diastolic`, `pulse`, `breathing`, `temperature`) VALUES
(34, '', 1, '2019-12-04 00:17:15', '0001-01-01 00:00:00', 99, 0, 0, 0, 0),
(35, '', 1, '2019-12-04 00:17:18', '0001-01-01 00:00:00', 93, 0, 0, 0, 0),
(36, '', 1, '2019-12-04 00:17:19', '0001-01-01 00:00:00', 87, 0, 0, 0, 0),
(37, '', 1, '2019-12-04 00:17:21', '0001-01-01 00:00:00', 85, 0, 0, 0, 0),
(38, '', 1, '2019-12-04 00:17:22', '0001-01-01 00:00:00', 87, 0, 0, 0, 0),
(39, '', 1, '2019-12-04 00:17:25', '0001-01-01 00:00:00', 97, 0, 0, 0, 0),
(40, '', 1, '2019-12-04 00:17:28', '0001-01-01 00:00:00', 85, 0, 0, 0, 0),
(41, '', 1, '2019-12-04 00:17:29', '0001-01-01 00:00:00', 94, 0, 0, 0, 0),
(42, '', 1, '2019-12-04 00:17:35', '0001-01-01 00:00:00', 92, 0, 0, 0, 0),
(43, '', 1, '2019-12-04 00:17:37', '0001-01-01 00:00:00', 100, 0, 0, 0, 0),
(44, '', 1, '2019-12-04 00:18:04', '0001-01-01 00:00:00', 88, 0, 0, 0, 0),
(45, '', 1, '2019-12-04 00:18:08', '0001-01-01 00:00:00', 90, 0, 0, 0, 0),
(46, 'kay', 1, '0001-01-01 00:00:00', '2019-12-04 00:18:10', 0, 0, 0, 0, 0),
(47, '', 1, '2019-12-04 00:18:23', '0001-01-01 00:00:00', 92, 0, 0, 0, 0),
(48, '', 1, '2019-12-04 03:32:08', '0001-01-01 00:00:00', 98, 0, 0, 0, 0),
(49, '', 1, '2019-12-04 03:32:15', '0001-01-01 00:00:00', 96, 0, 0, 0, 0),
(50, '', 1, '2019-12-04 03:54:31', '0001-01-01 00:00:00', 95, 0, 0, 0, 0),
(51, '', 1, '2019-12-04 03:54:43', '0001-01-01 00:00:00', 91, 0, 0, 0, 0),
(52, '', 1, '2019-12-04 03:54:44', '0001-01-01 00:00:00', 85, 0, 0, 0, 0),
(53, '', 1, '2019-12-04 03:54:45', '0001-01-01 00:00:00', 91, 0, 0, 0, 0),
(54, 'david', 1, '0001-01-01 00:00:00', '2019-12-04 03:54:46', 0, 0, 0, 0, 0),
(55, '', 1, '2019-12-04 03:54:49', '0001-01-01 00:00:00', 88, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bed_status`
--

CREATE TABLE `bed_status` (
  `id` int(11) NOT NULL,
  `bed_id` varchar(10) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bed_status`
--

INSERT INTO `bed_status` (`id`, `bed_id`, `patient_id`, `status`) VALUES
(1, 'Bed1', 1, 'Booked'),
(2, 'Bed2', 2, 'Booked');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `m_id` int(11) NOT NULL,
  `m_firstName` varchar(20) NOT NULL,
  `m_lastName` varchar(30) NOT NULL,
  `m_dob` date NOT NULL,
  `m_age` int(3) NOT NULL,
  `m_contact` int(15) NOT NULL,
  `m_email` varchar(50) NOT NULL,
  `m_loginid` varchar(20) NOT NULL,
  `m_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`m_id`, `m_firstName`, `m_lastName`, `m_dob`, `m_age`, `m_contact`, `m_email`, `m_loginid`, `m_password`) VALUES
(1, 'Jay', 'Lee', '1969-08-11', 50, 172222222, 'admin1@gmail.com', 'jaylee', '19690811'),
(1, 'Jay', 'Lee', '1969-08-11', 50, 172222222, 'admin1@gmail.com', 'jaylee', '19690811');

-- --------------------------------------------------------

--
-- Table structure for table `medicalstaff`
--

CREATE TABLE `medicalstaff` (
  `ms_id` int(11) NOT NULL,
  `ms_position` varchar(20) NOT NULL,
  `ms_firstName` varchar(30) NOT NULL,
  `ms_lastName` varchar(30) NOT NULL,
  `ms_dob` date NOT NULL,
  `ms_age` int(3) NOT NULL,
  `ms_contact` varchar(30) NOT NULL,
  `ms_email` varchar(50) NOT NULL,
  `ms_loginid` varchar(20) NOT NULL,
  `ms_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicalstaff`
--

INSERT INTO `medicalstaff` (`ms_id`, `ms_position`, `ms_firstName`, `ms_lastName`, `ms_dob`, `ms_age`, `ms_contact`, `ms_email`, `ms_loginid`, `ms_password`) VALUES
(1, 'On Call Medical Staf', 'Kay', 'Aum', '1991-08-28', 28, '+60165315884', 'vi-cious@hotmail.com', 'kayaum', '19910828'),
(2, 'Consultant', 'David', 'Woodfield', '1965-01-26', 54, '+60196557862', 'asd1234@gmail.com', 'davidwoodfield', '19650126');

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE `nurse` (
  `s_id` int(11) NOT NULL,
  `s_position` varchar(10) DEFAULT NULL,
  `s_firstName` varchar(30) DEFAULT NULL,
  `s_lastName` varchar(30) DEFAULT NULL,
  `s_dob` date DEFAULT NULL,
  `s_age` int(11) DEFAULT NULL,
  `s_contact` varchar(15) DEFAULT NULL,
  `s_email` varchar(30) DEFAULT NULL,
  `s_loginid` varchar(30) DEFAULT NULL,
  `s_password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`s_id`, `s_position`, `s_firstName`, `s_lastName`, `s_dob`, `s_age`, `s_contact`, `s_email`, `s_loginid`, `s_password`) VALUES
(1, 'Nurse', 'Samantha', 'Rea', '1993-07-20', 26, '126539856', 'samantha93@gmail.com', 'samantharea', '19930720'),
(2, 'Nurse', 'Elle', 'Ayriel', '1994-03-24', 25, '139745831', 'elle94@gmail.com', 'elleayriel', '19940324');

-- --------------------------------------------------------

--
-- Table structure for table `patientlimit`
--

CREATE TABLE `patientlimit` (
  `sa_id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `p_min_blood_sys` int(10) NOT NULL,
  `p_min_temperature` int(10) NOT NULL,
  `p_min_blood_dias` int(10) NOT NULL,
  `p_min_breathing_rate` int(10) NOT NULL,
  `p_min_pulse_rate` int(10) NOT NULL,
  `p_max_pulse` int(15) NOT NULL,
  `p_max_sys` int(15) NOT NULL,
  `p_max_dias` int(15) NOT NULL,
  `p_max_temperature` int(15) NOT NULL,
  `p_max_breathing` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientlimit`
--

INSERT INTO `patientlimit` (`sa_id`, `p_id`, `p_min_blood_sys`, `p_min_temperature`, `p_min_blood_dias`, `p_min_breathing_rate`, `p_min_pulse_rate`, `p_max_pulse`, `p_max_sys`, `p_max_dias`, `p_max_temperature`, `p_max_breathing`) VALUES
(12, 1, 100, 34, 60, 5, 50, 100, 150, 110, 40, 40),
(13, 2, 100, 34, 60, 5, 50, 100, 150, 110, 40, 40);

-- --------------------------------------------------------

--
-- Table structure for table `patientmedicaldetails`
--

CREATE TABLE `patientmedicaldetails` (
  `pm_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_systolic` int(3) NOT NULL,
  `p_diastolic` int(3) NOT NULL,
  `p_breathing` int(3) NOT NULL,
  `p_pulse` int(3) NOT NULL,
  `p_temperater` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientmedicaldetails`
--

INSERT INTO `patientmedicaldetails` (`pm_id`, `p_id`, `p_systolic`, `p_diastolic`, `p_breathing`, `p_pulse`, `p_temperater`) VALUES
(3, 1, 145, 89, 65, 78, 36),
(4, 3, 144, 89, 55, 66, 37),
(5, 2, 132, 89, 45, 66, 36),
(6, 4, 135, 89, 75, 79, 35),
(7, 5, 137, 89, 69, 76, 36),
(360, 2, 123, 123, 12, 12, 36);

-- --------------------------------------------------------

--
-- Table structure for table `patientrealtime`
--

CREATE TABLE `patientrealtime` (
  `pr_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_systolic` int(3) NOT NULL,
  `p_diastolic` int(3) NOT NULL,
  `p_breathing` int(3) NOT NULL,
  `p_pulse` int(3) NOT NULL,
  `p_temperature` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientrealtime`
--

INSERT INTO `patientrealtime` (`pr_id`, `p_id`, `p_systolic`, `p_diastolic`, `p_breathing`, `p_pulse`, `p_temperature`) VALUES
(505, 1, 0, 0, 0, 0, 0),
(506, 1, 114, 71, 12, 70, 36),
(507, 1, 130, 86, 19, 66, 36),
(508, 1, 140, 70, 15, 65, 36),
(509, 1, 143, 69, 14, 70, 36),
(510, 1, 142, 75, 13, 69, 36),
(511, 1, 133, 85, 16, 66, 36),
(512, 1, 136, 85, 19, 71, 36),
(513, 1, 110, 90, 16, 70, 36),
(514, 1, 141, 95, 19, 67, 36),
(515, 1, 119, 82, 12, 74, 36),
(516, 1, 133, 66, 17, 67, 36),
(517, 1, 142, 90, 19, 68, 36),
(518, 1, 107, 82, 12, 70, 36),
(519, 1, 116, 82, 12, 66, 36),
(520, 1, 113, 85, 13, 65, 36),
(521, 1, 107, 66, 12, 69, 36),
(522, 1, 113, 85, 12, 65, 36),
(523, 1, 134, 75, 15, 74, 36),
(524, 1, 121, 78, 17, 71, 36),
(525, 1, 121, 75, 18, 67, 36),
(526, 1, 139, 77, 14, 73, 36),
(527, 1, 109, 65, 14, 66, 36),
(528, 1, 140, 74, 12, 68, 36),
(529, 1, 123, 79, 18, 69, 36),
(530, 1, 144, 82, 17, 71, 36),
(531, 1, 138, 98, 12, 68, 36),
(532, 1, 135, 94, 13, 71, 36),
(533, 1, 138, 89, 18, 73, 36),
(534, 1, 133, 71, 12, 72, 36),
(535, 1, 109, 67, 12, 70, 36),
(536, 1, 105, 95, 15, 69, 36),
(537, 1, 119, 89, 19, 66, 36),
(538, 1, 111, 87, 14, 65, 36),
(539, 1, 106, 88, 12, 66, 36),
(540, 1, 136, 86, 17, 70, 36),
(541, 1, 137, 91, 14, 71, 36),
(542, 1, 134, 78, 16, 68, 36),
(543, 1, 140, 79, 14, 66, 36),
(544, 1, 110, 84, 15, 73, 36),
(545, 1, 108, 70, 14, 69, 36),
(546, 1, 123, 97, 13, 69, 36),
(547, 1, 120, 74, 17, 72, 36),
(548, 1, 129, 67, 17, 73, 36),
(549, 1, 135, 74, 14, 69, 36),
(550, 1, 129, 82, 15, 74, 36),
(551, 1, 114, 90, 17, 66, 36),
(552, 1, 130, 76, 18, 67, 36),
(553, 1, 138, 96, 18, 66, 36),
(554, 1, 130, 89, 13, 69, 36),
(555, 1, 108, 89, 17, 66, 36),
(556, 1, 138, 89, 16, 66, 36),
(557, 1, 143, 65, 16, 65, 36),
(558, 1, 132, 67, 13, 74, 36),
(559, 1, 116, 92, 19, 65, 36),
(560, 1, 139, 68, 17, 71, 36),
(561, 1, 141, 66, 15, 72, 36),
(562, 1, 126, 83, 16, 69, 36),
(563, 1, 142, 71, 12, 71, 36),
(564, 1, 137, 96, 13, 70, 36),
(565, 1, 127, 90, 17, 68, 36),
(566, 1, 116, 88, 18, 67, 36),
(567, 1, 134, 65, 15, 69, 36),
(568, 1, 141, 74, 19, 70, 36),
(569, 1, 110, 85, 14, 69, 36),
(570, 1, 108, 69, 12, 74, 36),
(571, 1, 143, 82, 18, 69, 36),
(572, 1, 113, 90, 17, 65, 36),
(573, 1, 139, 73, 14, 71, 36),
(574, 1, 142, 91, 13, 67, 36),
(575, 1, 127, 77, 13, 71, 36),
(576, 1, 144, 75, 13, 74, 36),
(577, 1, 110, 90, 18, 67, 36),
(578, 1, 0, 0, 0, 0, 0),
(579, 1, 0, 0, 0, 0, 0),
(580, 1, 0, 0, 0, 0, 0),
(581, 1, 143, 86, 14, 71, 36),
(582, 1, 113, 75, 14, 68, 36),
(583, 1, 130, 91, 19, 69, 36),
(584, 1, 109, 82, 12, 70, 36),
(585, 1, 144, 96, 15, 67, 36),
(586, 1, 132, 69, 19, 67, 36),
(587, 1, 129, 66, 13, 66, 36),
(588, 1, 127, 90, 13, 70, 36),
(589, 1, 144, 76, 14, 74, 36);

-- --------------------------------------------------------

--
-- Table structure for table `rederegister`
--

CREATE TABLE `rederegister` (
  `rederegister_id` int(11) NOT NULL,
  `ms_id` int(11) NOT NULL,
  `register_date` date DEFAULT NULL,
  `register_time` varchar(50) DEFAULT NULL,
  `deregister_date` date DEFAULT NULL,
  `deregister_time` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rederegister`
--

INSERT INTO `rederegister` (`rederegister_id`, `ms_id`, `register_date`, `register_time`, `deregister_date`, `deregister_time`) VALUES
(18, 1, '2019-12-04', '15:00   ', '2019-12-04', '17:00'),
(19, 1, '2019-12-05', '16:00   ', '2019-12-05', '20:00'),
(20, 1, '2019-12-11', '20:00   ', '2019-12-11', '22:00');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `s_id` int(11) DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  `register_time` varchar(50) DEFAULT NULL,
  `deregister_date` date DEFAULT NULL,
  `deregister_time` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `s_id`, `register_date`, `register_time`, `deregister_date`, `deregister_time`) VALUES
(8, 1, '2019-12-11', '23:00  ', '2019-12-11', '23:30'),
(9, 1, '2019-12-11', '23:00     ', '2019-12-11', '24:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addpatient`
--
ALTER TABLE `addpatient`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `bed_active`
--
ALTER TABLE `bed_active`
  ADD PRIMARY KEY (`ba_id`);

--
-- Indexes for table `bed_status`
--
ALTER TABLE `bed_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicalstaff`
--
ALTER TABLE `medicalstaff`
  ADD PRIMARY KEY (`ms_id`);

--
-- Indexes for table `nurse`
--
ALTER TABLE `nurse`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `patientlimit`
--
ALTER TABLE `patientlimit`
  ADD PRIMARY KEY (`sa_id`),
  ADD KEY `p_id_fk` (`p_id`);

--
-- Indexes for table `patientmedicaldetails`
--
ALTER TABLE `patientmedicaldetails`
  ADD PRIMARY KEY (`pm_id`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `patientrealtime`
--
ALTER TABLE `patientrealtime`
  ADD PRIMARY KEY (`pr_id`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `rederegister`
--
ALTER TABLE `rederegister`
  ADD PRIMARY KEY (`rederegister_id`),
  ADD KEY `ms_id` (`ms_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD KEY `s_id` (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addpatient`
--
ALTER TABLE `addpatient`
  MODIFY `p_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `bed_active`
--
ALTER TABLE `bed_active`
  MODIFY `ba_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `bed_status`
--
ALTER TABLE `bed_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `medicalstaff`
--
ALTER TABLE `medicalstaff`
  MODIFY `ms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `nurse`
--
ALTER TABLE `nurse`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patientlimit`
--
ALTER TABLE `patientlimit`
  MODIFY `sa_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `patientmedicaldetails`
--
ALTER TABLE `patientmedicaldetails`
  MODIFY `pm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=362;

--
-- AUTO_INCREMENT for table `patientrealtime`
--
ALTER TABLE `patientrealtime`
  MODIFY `pr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=590;

--
-- AUTO_INCREMENT for table `rederegister`
--
ALTER TABLE `rederegister`
  MODIFY `rederegister_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patientlimit`
--
ALTER TABLE `patientlimit`
  ADD CONSTRAINT `p_id_fk` FOREIGN KEY (`p_id`) REFERENCES `addpatient` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patientmedicaldetails`
--
ALTER TABLE `patientmedicaldetails`
  ADD CONSTRAINT `patientdetails_patient_id_fk` FOREIGN KEY (`p_id`) REFERENCES `addpatient` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patientrealtime`
--
ALTER TABLE `patientrealtime`
  ADD CONSTRAINT `realtime_patient_id_fk` FOREIGN KEY (`p_id`) REFERENCES `addpatient` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rederegister`
--
ALTER TABLE `rederegister`
  ADD CONSTRAINT `rederegister_ibfk_1` FOREIGN KEY (`ms_id`) REFERENCES `medicalstaff` (`ms_id`);

--
-- Constraints for table `register`
--
ALTER TABLE `register`
  ADD CONSTRAINT `register_nurse_id_fk` FOREIGN KEY (`s_id`) REFERENCES `nurse` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
